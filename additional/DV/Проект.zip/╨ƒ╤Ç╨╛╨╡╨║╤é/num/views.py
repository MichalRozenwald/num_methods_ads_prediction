from django.shortcuts import render
from num.forms import *
import num.modules as modules
from num.modules_new import *

def usecase1(request):
    form = ParamsForm()
    form3 = UseCase3Form()
    if request.method == 'POST':
        form1 = UseCase1Form(request.POST)
        if form1.is_valid():
            rho_a = form1.cleaned_data['rho_a']
            rho_b = form1.cleaned_data['rho_b']
            rho_c = form1.cleaned_data['rho_c']
            s_a = form1.cleaned_data['s_a']
            s_b = form1.cleaned_data['s_b']
            z_a = form1.cleaned_data['z_a']
            z_b = form1.cleaned_data['z_b']
            res_case1 = modules.use_case1([float(rho_a), float(rho_b), float(rho_c)], [float(s_a), float(s_b)],
                                      [float(z_a), float(z_b)])
            args = {'form' : form, 'form1' : form1, 'form3' : form3, 'res_case1' : res_case1}
            return render(request, 'main.html', args)
    form1 = UseCase1Form()
    args = {'form' : form, 'form1' : form1, 'form3' : form3}
    return render(request, 'main.html', args)

def usecase2(request):
    form1 = UseCase1Form()
    form = ParamsForm()
    form3 = UseCase3Form()
    res_case2 = modules.use_case2()
    args = {'form' : form, 'form1' : form1, 'form3' : form3, 'res_case2' : res_case2}
    return render(request, 'main.html', args)

def usecase3(request):
    form1 = UseCase1Form()
    form = ParamsForm()
    if request.method == 'POST':
        form3 = UseCase3Form(request.POST)
        if form3.is_valid():
            u_a = form3.cleaned_data['u_a']
            u_b = form3.cleaned_data['u_b']
            u_c = form3.cleaned_data['u_c']
            u_d = form3.cleaned_data['u_d']
            s_a = form3.cleaned_data['s_a']
            s_b = form3.cleaned_data['s_b']
            z_a = form3.cleaned_data['z_a']
            z_b = form3.cleaned_data['z_b']
            beta = form3.cleaned_data['beta']
            y_0 = form3.cleaned_data['y_0']
            x_0 = form3.cleaned_data['x_0']
            T = form3.cleaned_data['T']
            res_case3 = modules.use_case3([float(u_a), float(u_b), float(u_c), float(u_d)],
                                          [float(s_a), float(s_b)], [float(z_a), float(z_b)],
                                          float(beta), float(y_0), float(x_0), float(T))
            args = {'form' : form, 'form1' : form1, 'form3' : form3, 'res_case3' : res_case3}
            return render(request, 'main.html', args)
    form3 = UseCase3Form()
    args = {'form' : form, 'form1' : form1, 'form3' : form3}
    return render(request, 'main.html', args)

def set_mode(mode):
    err = []
    manual = False
    automat = False
    if not mode:
        err.append("Режим должен быть выбран.")
    elif mode[0] == 'manual':
        manual = True
    else:
        automat = True
    return err, manual, automat

def verify(rho_a, rho_b, rho_c, s_a, z_a, err):
    err_rho = False
    if float(rho_a) / 3 + float(rho_b) / 2 + float(rho_c) != 1:
        err_rho = True
    err_sz = False
    if s_a > z_a:
        err_sz = True
    if err_rho or err_sz:
        err.append("Должны выполняться свойства:")
    return err, err_rho

def verify_rho(rho, err):
    err_rho = False
    if 1 != round(integrate(func=rho, nnodes=100, interval=[0, 1]), 1):
        err_rho = True
        err.append("Должны выполняться свойства:")
    return err, err_rho

def main(request):
    if request.method == 'POST':
        form = ParamsFormNew(request.POST)
        mode = request.POST.getlist('mode')
        err, manual, automat = set_mode(mode)
        if err:
            args = {'form' : form, 'errs' : err}
            return render(request, 'newmain.html', args)
        if not form.is_valid():
            args = {'form' : form, 'errs' : [str(form.errors)]}
            return render(request, 'newmain.html', args)
        if form.is_valid():
            rho_expr = form.cleaned_data['rho']
            S_expr = form.cleaned_data['S']
            z_expr = form.cleaned_data['z']
            if manual:
                beta = float(form.cleaned_data['beta'])
                x_0 = float(form.cleaned_data['x_0'])
            if automat:
                beta_min = float(form.cleaned_data['beta_min'])
                beta_max = float(form.cleaned_data['beta_max'])
            f_expr = form.cleaned_data['f']
            y_0 = float(form.cleaned_data['y_0'])
            T = float(form.cleaned_data['T'])
            if manual:
                are_errors, output = initialize_functions(rho_expr, z_expr, S_expr, f_expr, beta=beta)
            else:
                are_errors, output = initialize_functions(rho_expr, z_expr, S_expr, f_expr,
                                                          beta_min=beta_min, beta_max=beta_max)
            if are_errors:
                for e in output:
                    err.append(e)
                args = {'form' : form, 'automat' : automat, 'manual' : manual,
                        'errs' : err}
                return render(request, 'newmain.html', args)
            else:
                rho, z, S, f = output
                err, err_rho = verify_rho(rho, err)
                if err:
                    args = {'form' : form, 'automat' : automat, 'manual' : manual,
                    'errs' : err, 'err_rho' : err_rho}
                    return render(request, 'newmain.html', args)
                else:
                    if manual:
                        is_good_res, log_res = solver(False, rho, z, S, f, y_0, x_0, T)
                    else:
                        x_0 = S(0)
                        is_good_res, log_res = solver(True, rho, z, S, f, y_0, x_0, T)
                    args = {'form' : form, 'automat' : automat, 'manual' : manual, 'res' : log_res,
                            'is_good_res' : is_good_res, 'rho' : True, 'z' : True, 'S' : True}
                    return render(request, 'newmain.html', args)
        args = {'form' : form, 'automat' : automat, 'manual' : manual, 'err' : err}
        return render(request, 'newmain.html', args)
    else:
        form = ParamsFormNew()
        args = {'form' : form}
    return render(request, 'newmain.html', args)

def start(request):
    if request.method == 'POST':
        form = ParamsForm(request.POST)
        form1 = UseCase1Form(request.POST)
        form3 = UseCase3Form(request.POST)
        mode = request.POST.getlist('mode')
        err, manual, automat = set_mode(mode)
        if form.is_valid():
            rho_a = form.cleaned_data['rho_a']
            rho_b = form.cleaned_data['rho_b']
            rho_c = form.cleaned_data['rho_c']
            s_a = form.cleaned_data['s_a']
            s_b = form.cleaned_data['s_b']
            z_a = form.cleaned_data['z_a']
            z_b = form.cleaned_data['z_b']
            if manual:
                beta = form.cleaned_data['beta']
            if automat:
                beta_min = form.cleaned_data['beta_min']
                beta_max = form.cleaned_data['beta_max']
            f = form.cleaned_data['f']
            y_0 = form.cleaned_data['y_0']
            x_0 = form.cleaned_data['x_0']
            T = form.cleaned_data['T']
            err, err_rho, err_sz = verify(rho_a, rho_b, rho_c, s_a, z_a, err)
            args = {'form' : form, 'form1' : form1, 'form3' : form3, 'automat' : automat, 'manual' : manual,
                'errs' : err, 'err_rho' : err_rho, 'err_sz' : err_sz}
            return render(request, 'main.html', args)
        args = {'form' : form, 'form1' : form1, 'form3' : form3, 'automat' : automat, 'manual' : manual,
                'err' : err}
        return render(request, 'main.html', args)
    else:
        form = ParamsForm()
        form1 = UseCase1Form()
        form3 = UseCase3Form()
        args = {'form' : form, 'form1' : form1, 'form3' : form3}
    return render(request, 'main.html', args)

def automat(request):
    automat = True
    manual = False
    form = ParamsFormNew()
    args = {'form' : form, 'automat' : automat, 'manual' : manual}
    return render(request, 'newmain.html', args)

def manual(request):
    manual = True
    automat = False
    form = ParamsFormNew()
    args = {'form' : form, 'automat' : automat, 'manual' : manual}
    return render(request, 'newmain.html', args)