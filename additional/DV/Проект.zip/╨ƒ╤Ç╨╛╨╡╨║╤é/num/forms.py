from django import forms

class ParamsFormNew(forms.Form):
    rho = forms.CharField(initial="6*w*(1-w)")
    S = forms.CharField(initial="4*t+cos(t)")
    z = forms.CharField(initial="3*t+sin(t)")
    beta = forms.DecimalField(initial=0.01, required=False)
    beta_min = forms.DecimalField(required=False, initial=-1)
    beta_max = forms.DecimalField(required=False, initial=1)
    f = forms.CharField(initial="beta*(S-x)")
    y_0 = forms.DecimalField(min_value=0, max_value=1, initial=0)
    x_0 = forms.DecimalField(initial=0, required=False)
    T = forms.DecimalField(initial=1)

class ParamsForm(forms.Form):
    f_types = [["b(x - z)", "b(x - z)"]]
    rho_a = forms.DecimalField()
    rho_b = forms.DecimalField()
    rho_c = forms.DecimalField()
    s_a = forms.DecimalField(min_value=1) # a > b
    s_b = forms.DecimalField()
    z_a = forms.DecimalField(min_value=1) # a > b
    z_b = forms.DecimalField()
    beta = forms.DecimalField(required=False)
    beta_min = forms.DecimalField(required=False)
    beta_max = forms.DecimalField(required=False)
    f = forms.ChoiceField(choices=f_types)
    y_0 = forms.DecimalField(min_value=0, max_value=1)
    x_0 = forms.DecimalField()
    T = forms.DecimalField()
    #num_nodes = forms.DecimalField(min_value=1)
    #net_type = forms.ChoiceField(choices=["обычная", "нули многочлена Чебышева"])
    #beta_iters = forms.DecimalField()

class UseCase1Form(forms.Form):
    rho_a = forms.DecimalField(initial = -6)
    rho_b = forms.DecimalField(initial = 6)
    rho_c = forms.DecimalField(initial = 0)
    s_a = forms.DecimalField(min_value=1, initial=3) # a > b
    s_b = forms.DecimalField(initial=0)
    z_a = forms.DecimalField(min_value=1, initial=4) # a > b
    z_b = forms.DecimalField(initial=0)

class UseCase3Form(forms.Form):
    u_a = forms.DecimalField(initial=2)
    u_b = forms.DecimalField(initial=-3)
    u_c = forms.DecimalField(initial=0)
    u_d = forms.DecimalField(initial=1)
    s_a = forms.DecimalField(min_value=1, initial=3) # a > b
    s_b = forms.DecimalField(initial=0)
    z_a = forms.DecimalField(min_value=1, initial=4) # a > b
    z_b = forms.DecimalField(initial=0)
    beta = forms.DecimalField(initial=0.01)
    y_0 = forms.DecimalField(min_value=0, max_value=1, initial=0)
    x_0 = forms.DecimalField(initial=0)
    T = forms.DecimalField(initial=1)