import numpy as np
import matplotlib.pyplot as plt
import os.path
import errno

def mock_vals(use_case):
    if use_case == 2:
        xnet = np.linspace(0, 1, 10)
        integr_vals = [2 * (x ** 3) - 3 * (x ** 2) + 1 for x in xnet]
        return integr_vals
    elif use_case == 2.5:
        inter_coefs = [2, -3, 1]
        return inter_coefs
    elif use_case == 3:
        x0 = 0
        y0 = 0
        beta = 0.01
        T = 1
        u_coefs = [2, -3, 0, 1]
        z_coefs = [4, 0]
        return x0, y0, beta, T, u_coefs, z_coefs
    return

def verify_file(file_name):
    if not os.path.isfile(file_name):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), file_name)
    return 0

def write_to_file(file_name, str):
    f = open('outputs/{}'.format(file_name), 'w')
    f.write(str)
    f.close()
    msg = 'Запись в файл завершена.'
    return msg

# func_type = ("lin", "quad")
# "lin" = linear (ax+b)
# "quad" = quadratic (ax^2 + bx + c)
# func_coefs: list of function's coefficients
# dim: net dimension
# nnodes: number of nodes in net for every variable
# interval: tuple of two elements: min value, max value of argument
def tabulate_func(func_type, func_coefs, dim=1, nnodes=10, interval=(0,10)):
    valid_types = ("lin", "quad")
    xnet = np.linspace(interval[0], interval[1], nnodes)
    if func_type == 'lin':
        assert len(func_coefs) == 2
        a = func_coefs[0]
        b = func_coefs[1]
        tab = np.array([a * x + b for x in xnet])
    elif func_type == 'quad':
        assert len(func_coefs) == 3
        a = func_coefs[0]
        b = func_coefs[1]
        c = func_coefs[2]
        tab = np.array([a * x ** 2 + b * x + c for x in xnet])
    else:
        raise Exception("func_type is not a valid value:{0}. Use one of the following: {1}"\
                        .format(func_type, valid_types))
    return tab

# tab - табулированная функция, np.array
def integrate(tab, y_interv=None, T=None):
    integr_vals = mock_vals(2)
    msg = "Интеграл посчитан: {}\n".format(integr_vals)
    msg2 = write_to_file('integr_vals', ';'.join([str(i) for i in integr_vals]))
    return [msg, msg2], integr_vals

# tab_s - табулированная S(t), np.array
# tab_z - табулированная z(t), np.array
# tab_rho - табулированная rho(omega), np.array
# tab_u - табулированная U(y), np.array
def interpolate(tab_s=None, tab_z=None, tab_rho=None, tab_u=None):
    interpol_vals = mock_vals(2.5)
    msg = "Найдены коэффициенты интерполяции: {}".format(interpol_vals)
    msg2 = write_to_file('interpol_vals', ';'.join([str(i) for i in interpol_vals]))
    return [msg, msg2], interpol_vals

def funcFBeta(z_coefs, beta, x_val, t_val, s_coefs=None, f_type=None):
    return beta * (x_val - (z_coefs[0] * t_val + z_coefs[1]))

def diff(func_tab):
    return 0

def cauchy(x_0, y_0, beta, T, u_coefs, z_coefs, s_coefs=None, nnodes=10):
    x = [x_0,]
    y = [y_0,]
    tnet = np.linspace(0, T, nnodes)
    for iter in range(1, len(tnet)):
        x_old = x[iter - 1]
        y_old = y[iter - 1]
        t_old = tnet[iter - 1]
        t_new = tnet[iter]
        U = u_coefs[0] * y_old ** 3 + u_coefs[1] * y_old ** 2 + u_coefs[2] * y_old + u_coefs[3]
        x_new = x_old + (t_new - t_old) * z_coefs[0] * U
        y_new = y_old + (t_new - t_old) * funcFBeta(z_coefs, beta, x_old, t_old)
        x.append(x_new)
        y.append(y_new)
    return (tnet, x, y)

def use_case1(rho, s, z):
    rho_tab = tabulate_func("quad", rho, interval=(0,1))
    z_tab = tabulate_func("lin", z)
    s_tab = tabulate_func("lin", s)
    write_to_file('usecase1/z_tab', ';'.join([str(i) for i in z_tab]))
    write_to_file('usecase1/s_tab', ';'.join([str(i) for i in s_tab]))
    msg = write_to_file('usecase1/rho_tab', ';'.join([str(i) for i in rho_tab]))

    plt.figure(figsize=(8,6))
    x = np.linspace(0, 1, 100)
    plt.plot(x, -6*x**2+6*x, label=r"$\rho(\omega)=-6x^2+6x$", linewidth=3)
    plt.legend(prop={'size':20}, loc=2)
    plt.savefig('outputs/usecase1/rho_graph.png')
    plt.close()

    plt.figure(figsize=(8,6))
    plt.plot(rho_tab, label=r"$\rho(\omega)=-6x^2+6x$", linewidth=3)
    plt.legend(prop={'size':20}, loc=2)
    plt.savefig('outputs/usecase1/rho.png')
    plt.close()

    plt.figure(figsize=(8,6))
    plt.plot(z_tab, label=r"$z(t)=4t$", linewidth=3)
    plt.plot(s_tab, label=r"$S(t)=3t$", linewidth=3)
    plt.legend(prop={'size':20}, loc=2)
    plt.savefig('outputs/usecase1/sz.png')
    plt.close()

    return msg

def use_case2():
    file_name = 'outputs/usecase1/rho_tab'
    verify_file(file_name)
    f = open(file_name)
    rho_tab = f.read().split(';')
    msg = ["Чтение из файла завершено.",]
    msgs, integr_vals = integrate(rho_tab)
    msgs2, interpol_vals = interpolate(tab_u=integr_vals)

    plt.figure(figsize=(8,6))
    plt.plot(integr_vals, label=r"$U(y)=2y^3-3y^2+1$", linewidth=3)
    plt.legend(prop={'size':20}, loc=3)
    plt.savefig('outputs/usecase2/u.png')
    plt.close()

    return msg + msgs + msgs2

def use_case3(u, s, z, beta, y_0, x_0, T):
    сauchy_res = cauchy(x_0, y_0, beta, T, u, z)
    msg = "Решение задачи Коши посчитано:"

    plt.figure(figsize=(8,6))
    plt.plot(сauchy_res[0], сauchy_res[1], label=r"$x(t)$", linewidth=4)
    plt.plot(сauchy_res[0], сauchy_res[2], label=r"$y(t)$", linewidth=8)
    plt.legend(prop={'size':20}, loc=3)
    plt.savefig('outputs/usecase3/cauchy_res.png')
    plt.close()

    return msg
