from django.conf.urls import include, url
from django.contrib import admin
from num import views

urlpatterns = [
    # Examples:
    # url(r'^$', 'project.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', views.main, name='main'),
    url(r'^start/$', views.start, name='start'),
    url(r'^auto$', views.automat, name='automat'),
    url(r'^manual$', views.manual, name='manual'),
    url(r'^save/$', views.start, name='save'),
    url(r'^use_case1/$', views.usecase1, name='usecase1'),
    url(r'^use_case2/$', views.usecase2, name='usecase2'),
    url(r'^use_case3/$', views.usecase3, name='usecase3'),
]
